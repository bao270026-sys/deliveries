#!/usr/bin/env python3
"""Prepare local tasks and publish the copy-to-image contract (standard library only)."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
import uuid

SKILL = Path(__file__).resolve().parents[1]
WORKFLOW = "openvam-pair-v1"
MIN_POSTER_PAGES = 2
TASK_TYPES = {"steps"}  # Local software-only scope
CONTENT_KINDS = {None, "pure_novel", "operation_guide", "travel_route"}
STEP_TEMPLATE = "文案定稿的统一纯色满版背景；仅第一页的主题标题直接排在底色上，第二页起不添加标题；真实步骤截图为主体，截图下方的编号和说明直接排在底色上。"
STEP_UNIFORM_RULE = '仅软件步骤类 steps：同一主题的教程截图统一展示尺寸、图位和视觉尺度，让整套看起来属于同一套真实软件界面。文案端优先选用同设备、同版本、同分辨率的连续素材，在 layout 定稿统一截图框宽高、等比例缩放方式，以及需要补齐的无关边缘或清晰度增强范围。原图比例不一致时，完整界面保持原始宽高比等比例放入统一图位，可用与真实界面衔接的无信息边缘补足外部尺寸；禁止横向或纵向拉伸，也不裁掉关键内容凑同尺寸。可用 AI 准确补齐不涉及功能与信息的空白边缘，并增强真实界面的清晰度；原图或可靠依据不能辨认的文字和细节不靠 AI 猜测恢复。统一的是展示尺寸与视觉风格，不是把实际不同页面或状态改成相同界面：除已定稿的截图年份局部处理外，不增删或伪造功能、按钮、文字、数值、开关状态，不拼造不存在的操作步骤。真实布局和操作关系保持不变；关键控件须清楚可读，尺寸统一与可读性冲突时先调整整套图位、减少同页图数或由文案端调整分页，不能靠变形或编造解决。生图端只执行已定稿的补边、增强及截图年份局部处理范围，缺少关键界面仍按补料流程处理；不新增成图后的专项检查，non_steps 与 operation_guide 不受本条变更影响。'
STEP_PASTE_RULE = '步骤类截图按原始比例平直铺放，默认完整呈现；仅按定稿裁去不损失重要信息的人脸边缘区域，保留下来的画面等比例缩放，准确保留操作对象、关键文字、按钮、动作和状态关系。'
STEP_SCREENSHOT_RULE = '软件步骤图优先保留完整屏幕或完整软件窗口，不只截按钮、菜单项或一小块操作区域；保留页面标题、导航、相邻选项及操作前后状态，让读者看得出位置与上下文。截图在最终成图中要足够大，关键按钮、文字、开关和标注落点清楚可辨；不能把完整界面缩成看不清的小图。空间不足时，文案端先减少同页截图数，按原图比例选择左右或上下分区排放，必要时在18页内拆页，每张仍完整展示，不把同一截图切成碎片。模板、填满画面和合并省页均不能优先于截图完整与操作可读性；生图端需要改变图数或分页时退回文案端调整。'
FACE_RULE = '仅执行每项素材已定稿的 face_plan：crop 按指定边缘范围裁切，anime 仅将指定脸部改为不对应真人身份的动漫脸。准确保留计划列出的主体、动作、关键文字、按钮与状态信息，以及脸部表情朝向和演示定位；文案已在 description 与 layout 定稿保留的球星、运动员真实面容，以及原生动漫人物、游戏角色保持原貌；混合人物素材仅处理 face_plan 指定的普通素人。小预览和缩略头像也逐项按计划执行，不重新选择处理方法；发现未定稿的人脸或计划缺失时交回文案端补齐。'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    data = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    require(isinstance(data, dict), f"JSON 顶层应为对象：{path}")
    return data


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    name = None
    try:
        with tempfile.NamedTemporaryFile("w", dir=path.parent, encoding="utf-8",
                                         delete=False) as stream:
            name = stream.name
            json.dump(data, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        os.replace(name, path)
    finally:
        if name and Path(name).exists():
            Path(name).unlink()


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def local_file(folder, relative):
    require(isinstance(relative, str) and relative, "素材路径应为非空字符串")
    path = Path(relative)
    require(not path.is_absolute(), f"使用相对主题目录的路径：{relative}")
    target = (Path(folder) / path).resolve()
    require(target.is_relative_to(Path(folder).resolve()), f"路径超出主题目录：{relative}")
    require(target.is_file(), f"文件不存在：{target}")
    return target


def manifest(root):
    data = read_json(Path(root) / ".workflow/run_manifest.json")
    require(data.get("workflow") == WORKFLOW, "目录已属于其他批次，请使用新的输出目录")
    require(isinstance(data.get("topics"), list) and data["topics"], "批次清单缺少主题")
    return data


def identity(folder):
    folder = Path(folder).resolve()
    data = manifest(folder.parent)
    items = [item for item in data["topics"] if item["folder_name"] == folder.name]
    require(len(items) == 1, "主题目录与批次清单不一致")
    entry = items[0]
    marker = folder / ".workflow/run_id.txt"
    require(marker.read_text().strip() == data["run_id"], "运行标记与批次不一致")
    return {"run_id": data["run_id"], "topic_id": entry["topic_id"], "topic": entry["topic"]}


def init(root, topics):
    root = Path(root).resolve()
    require(topics and all(isinstance(t, str) and t.strip() for t in topics), "需要非空主题")
    topics = [topic.strip() for topic in topics]
    path = root / ".workflow/run_manifest.json"
    if path.exists():
        data = manifest(root)
        require([item["topic"] for item in data["topics"]] == topics,
                "主题清单与本目录批次不同，请使用新的输出目录")
    else:
        entries = []
        for index, topic in enumerate(topics, 1):
            slug = re.sub(r'[\x00-\x1f<>:"/\\|?*]', "_", topic).strip(" .")[:60] or "主题"
            name = f"{index:02d}_{slug}"
            require(not (root / name).exists(), f"主题目录已有内容：{root / name}")
            entries.append({"topic_id": f"{index:02d}", "topic": topic,
                            "folder_name": name, "relative_dir": name})
        data = {"schema_version": 1, "workflow": WORKFLOW,
                "run_id": uuid.uuid4().hex, "topics": entries}
        write_json(path, data)
    tasks = []
    for item in data["topics"]:
        folder = root / item["folder_name"]
        internal = folder / ".workflow"
        internal.mkdir(parents=True, exist_ok=True)
        marker = internal / "run_id.txt"
        if marker.exists():
            require(marker.read_text().strip() == data["run_id"], f"运行标记冲突：{folder}")
        else:
            marker.write_text(data["run_id"] + "\n", encoding="utf-8")
        task = dict(item, run_id=data["run_id"])
        write_json(internal / "task.json", task)
        tasks.append(dict(task, folder=str(folder), draft=str(internal / "copy_draft.json")))
    return {"run_id": data["run_id"], "root": str(root), "tasks": tasks}


def normalize_body(body):
    require(isinstance(body, str), "body_copy 应为字符串")
    body = body.replace("\r\n", "\n").replace("\r", "\n").strip()
    require("\\n" not in body and "\\r" not in body, "正文应使用实际换行符")
    body = re.sub(r"\n[ \t]*\n(?:[ \t]*\n)*", "\n\n", body)
    parts = [part.strip() for part in body.split("\n\n")]
    require(len(parts) >= 2 and all(parts), "正文需要引言和自然分段")
    require(all("\n" not in part for part in parts), "段内连续书写，段间恰好一个空行")
    return "\n\n".join(parts)


def validate_face_plan(item):
    plan = item.get("face_plan")
    require(isinstance(plan, list), "每项素材需要 face_plan；无需要处理的普通素人人脸（包括仅有球星、运动员）时显式填 []")
    for action in plan:
        require(isinstance(action, dict) and isinstance(action.get("action"), str)
                and action["action"] in {"crop", "anime"},
                "face_plan.action 应为已定稿的 crop 或 anime")
        require(all(isinstance(action.get(key), str) and action[key].strip()
                    for key in ("target", "preserve")),
                "face_plan 需要具体位置/裁边范围 target 及重要保留信息 preserve")
    return plan


def validate_task_design(data):
    task_type = data.get("task_type")
    require(task_type in TASK_TYPES, "任务级 task_type 应为 steps 或 non_steps")
    require(all(not any(key in page for key in ("task_type", "template", "content_kind"))
                for page in data["pages"]), "整题类型由顶层 task_type 确定，页面只填写制作稿")
    content_kind = data.get("content_kind")
    require((content_kind is None or isinstance(content_kind, str)) and content_kind in CONTENT_KINDS, "content_kind 应省略或为 pure_novel、operation_guide、travel_route")
    require(content_kind is None or task_type == "non_steps", "content_kind 仅用于 non_steps")
    if task_type == "non_steps":
        require(isinstance(data.get("color_theme"), str) and data["color_theme"].strip(),
                "自由排版任务需要 color_theme，说明整题统一色调")
        require("background" not in data and all(not any(key in page for key in
                ("background", "template_path", "template_sha256")) for page in data["pages"]),
                "自由排版任务使用 color_theme 与实际素材")
        return
    require("color_theme" not in data, "纯色步骤模板任务使用 background 定稿")
    background = data.get("background")
    require(isinstance(background, dict), "纯色步骤模板任务需要 background 对象")
    require(isinstance(background.get("name"), str) and background["name"].strip(),
            "主题背景需要色名 name")

    def color(value):
        require(isinstance(value, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", value),
                "背景色值应为 #RRGGBB")
        return value.upper()

    common_color = color(background.get("color"))
    for page in data["pages"]:
        item = page.get("background")
        require(isinstance(item, dict), f"第{page['page']}页需要 background 定稿")
        require(color(item.get("color")) == common_color,
                f"第{page['page']}页基础底色与主题不同；局部不同底色写入 regions")
        regions = item.get("regions", [])
        require(isinstance(regions, list), "background.regions 应为数组")
        for region in regions:
            require(isinstance(region, dict)
                    and all(isinstance(region.get(key), str) and region[key].strip()
                            for key in ("area", "reason")),
                    "局部背景例外需要 area 和 reason，说明具体区域与用途")
            color(region.get("color"))


def validate_travel_page(page):
    """Structural guard; factual photo identity and route order remain human-reviewed."""
    images = page.get("image_ids", [])
    require(len(images) == 4 and len(set(images)) == 4,
            "旅游路线每页须恰好四个不同真实照片素材；不足先补料或重新规划")
    arrows = [a for a in page.get("annotations", []) if a.get("kind") == "arrow"]
    require(len(arrows) == 3, "旅游路线四图需三条方向明确的连接箭头")


def page_prompt(page, references, task_type, *, background=None, color_theme=None, content_kind=None):
    require(task_type in TASK_TYPES, "任务级 task_type 应为 steps 或 non_steps")
    require((content_kind is None or isinstance(content_kind, str)) and content_kind in CONTENT_KINDS, "需要有效的 content_kind")
    require(content_kind is None or task_type == "non_steps", "content_kind 仅用于 non_steps")
    pure_novel = task_type == "non_steps" and content_kind == "pure_novel"
    operation_guide = task_type == "non_steps" and content_kind == "operation_guide"
    travel_route = task_type == "non_steps" and content_kind == "travel_route"
    reference_map = {item["id"]: item for item in references}
    material_rule = ('角色、物体、商品、装备、场景、界面、logo 及装饰插画均以本页 image_ids 对应的实际素材为依据，主体身份、原生标志含义、文字与数值须正确，不虚构对象或数据。原图本身覆盖其中已有内容，无需给每个物体另配参考；纯色背景、定稿文字、箭头、框线和排版图形属于设计元素。素材不足时交回文案端补齐。' if task_type == "steps" else
                     '用于准确讲解的具体人物、商品型号、游戏角色、装备、NPC、物品、界面、logo 及场景，以本页 image_ids 对应的实际素材为依据，保留可辨认的外观、原生标志含义、文字与数值。原图本身覆盖其中已有内容，无需给每个物体另配参考。上述具体对象素材不足时交回文案端补齐；通用场景与辅助元素按下述规则生成，无需逐一配参考。')
    lines = [
        '页面底部优先安排本页已经定稿的有效文字，靠近安全边距并保留清晰阅读空间，不另造底部结语、提醒、总结或延伸内容，不专门用 AI 生成物件填底；自然延续的背景可以保留。此规则优先于通用辅助物件生成许可。steps 底部只使用已有对应截图的操作说明，保持截图完整及说明紧接截图下方，不添加额外页脚，不为贴底裁图或拉伸截图。保留原有开头引言规则，不以填版为由编造内容。',
        '车辆介绍、推荐和选购主题：对每个具体车型及配置版本，在 body_copy 和对应页面 text_blocks 都写入经外部资料实际核实的人民币价格或价格区间，并明确价格类型（如厂商指导价、地区经销商报价或落地价）；车型、配置与价格一一对应，比较时保持价格口径一致，必要地区与适用条件随价格说明。不得编造价格或用未核实估值填空；无可靠价格时继续查证，仍缺则记录资料缺口，不把缺价格稿当完整稿交付。核实日期和支持价格的来源链接保留在 references 调研/交接记录中，不额外印来源网址。正常文案和文字复查逐车型核对正文与图片中的价格、类型、配置及遗漏，不新增检查轮次，生图端不自行补价。',
        "制作一张严格竖版 3:4、完全不透明的 PNG 图片。",
        f"整题类型：{task_type}；本题所有页面沿用同一类型。",
        "全部新增可见文字只使用本页 text_blocks 定稿，不擅自润色，不额外添加来源名称、网址或“截图来源”等说明，也不补充防御性、免责式或交代整理口径的底部说明、角注；制作指令不印入画面。",
        ("充分呈现本页定稿的有用信息、相关素材和具体细节，减少空泛标题和大块留白；保持文字清楚、画面不拥挤，不靠放大元素凑版面，不自行增加定稿外的文字、事实" + ("或素材。" if task_type == "steps" else "或讲解素材。")),
        ("本题为纯小说内容，优先使用对应小说的真实书本封面作为参考图；有映射封面时按稿呈现，保留书名、作者及封面识别信息，不虚构或改成其他封面。实在没有合适封面时才按定稿制作纯文字页，仅用定稿文字和抽象排版元素，不用影视剧照、无关图片或虚构封面替代，不虚构具象人物或场景。" if pure_novel else "每张成图都必须实际使用并呈现本页映射的相关参考素材，不能只在字段中列素材而画面没有，不做纯文字页；模板或抽象背景不能代替主题参考素材。仅 non_steps 的局部无配图信息区可由文字自然利用空间，不代表整页可以没有配图；素材须与内容相关，不为填空硬凑。" + material_rule),
        "主题未要求人物时，不添加普通人物或人脸。" + FACE_RULE,
        ("去水印仅处理来源网站、账号或平台额外叠加的水印；游戏和软件原有的标志、卡面边框、阵营或类型图标、数值、文字及状态属于内容，不按角落位置当作水印去除；归属不明时核对来源。" if task_type == "steps" else "去水印仅处理来源网站、账号或平台额外叠加的标记；保留有信息意义的原生标志、阵营、类型、稀有度、数值与状态，归属不明时核对来源。"),
    ]
    if task_type == "steps":
        lines.extend([
            '仅软件步骤类 steps：每张成图最多展示两张截图，可只放一张；按画面中实际呈现的截图数量计算，不能把多张拼成一个素材文件来规避上限。每张截图只配一句描述其当前单个操作的简短说明，紧接对应截图下方，不写在截图内或覆盖界面；必要的箭头和定位框仍可按定稿标注在截图上。关键内容放不下时由文案端调整分页，不通过增加同页截图或挤小文字解决。非步骤类及 operation_guide 的图数规则不变。',
            '仅软件 steps 的截图年份处理：普通示意日期中的日历年份早于 2026 时，用 AI 紧贴年份数字局部修补为 2026，只改年份数字；普通 2026 年及以后日期保持不变。用于识别软件版本的日历年份则局部擦除而非替换，例如 AutoCAD 2020 → AutoCAD，不能改为 AutoCAD 2026 或虚称新版。非年份的四位编号、代码及其他数字不得改动；月、日、按钮、控制项、其他数据及真实功能保持不变。若修改导致无效日期（如 2024-02-29 改成不存在的 2026-02-29）或篡改影响正确性的真实日期记录，改找真实替代或演示素材，不伪造；仍无合适素材则记录冲突与缺口。必要年份选择控件不改动，不以去版本年份掩盖实际功能适用性。文案端在 reference_images.description 与 layout 写明原年份、位置、动作（替换数字或擦除）、修改范围及适用性依据；生图端只执行列明局部，原始截图文件不改，其余内容保真。这是原生文字数字保真规则的限定例外，不扩展到 non_steps。既有步骤截图完整性、可读性及文字复查中核对年份与周边，无额外检查轮次。仅应用于今后新任务，不改用户电脑、冻结批次或历史成果。',
            STEP_PASTE_RULE,
            STEP_UNIFORM_RULE,
            STEP_SCREENSHOT_RULE,
            "素材参考图不许过度洗图，要像参考图直接粘贴进版面一样。保留原图的主体细节、文字（仅 steps 已定稿的英文转简体中文翻译及截图年份局部处理除外）、图标、颜色、比例和布局，处理以等比例缩放、排版及添加定稿文字和标注为主。界面截图默认完整展示，保留原有状态栏和导航栏；去脸裁边按本页 layout 和人脸规则执行；素材含整部手机时，仅去除屏幕外的机身、边框、摄像头、按键及周围环境。截图平直铺放，不添加手机外壳、透视、反光或立体包装效果。",
            "验收以主要信息正确、步骤可操作和截图无外围手机边框为准，不追求像素级一致。不影响理解的原截图小字差异、轻微比例或间距偏差可以接受；关键按钮、步骤、主体身份、重要数字和事实须正确，重要内容不能缺失。截图被裁成失去上下文的小块，或缩小到关键按钮与操作位置看不清，属于操作可读性问题，不能按轻微比例差异放行。",
            "仅软件步骤任务采用标题—截图—短说明结构：仅第一页的主题标题在页面最上方，第二页起不添加标题，真实完整截图在中部，每张截图只配当前单个操作的简短说明，放在对应截图下方；不排左图右长文，不附加原理、背景或总结长段。每张成图最多两张截图，可只放一张，不为填满版面强塞多图。步骤任务以完整截图和操作文字可读性确定尺寸，不受非步骤主体面积规则限制。截图字小或细节密集时，等比例放大整张截图、减少每页截图数量或在每题最多18页内调整分页；按定稿保留关键屏幕信息，去脸裁边以不损失重要信息为前提；不拉伸、不改造真实界面、不猜测补字；仅可按定稿准确补无关边缘、增强真实界面清晰度及执行上述截图年份局部处理。上述分页由文案端定稿，本次只制作这一页；无法容纳时交回文案端调整，不自行增删页面或本页素材。",
            "真实步骤截图保留界面文字（已定稿的英文转简体中文翻译及截图年份局部处理除外）、按钮位置和操作关系；具体操作按 text_blocks 可见呈现，箭头终点或框选范围精确对应 annotations 指定的原图按钮与位置。首次生成和纠错重生成都保留上述素材保真要求。",
            "按定稿完整呈现操作序列及全部步骤截图，文字直接说明动作和顺序；不自行删图、省步骤或减页，仅执行文案端在多渠道确实缺图后记录的适度精简安排。",
        ])
        lines.extend([
            "输入图1是版式参考，只负责排版风格；输入图2起是素材参考，负责真实内容。不得用模板中的界面、文字或图标替换实际素材，模板示例文案、占位文字和轮播按钮不属于本页内容。",
            STEP_TEMPLATE,
            "文字直接排在文案定稿的统一纯色背景上，通过字号、字重、颜色和间距区分层级。真实软件界面保持矩形，平直直接贴在背景上，不添加手机外壳、手机外框、描边、投影或其他装饰；保留必要操作箭头与定位框；新增文字不套独立底板，真实截图内原有的 UI 框和卡片保持原貌。",
            "可酌情在排版和标注中保留少量人工整理感，如间距轻微不对称、手绘箭头线条略有不均，箭头终点仍准确，内容与可读性保持不变。",
            f"本主题统一背景：{background['name']}（{background['color']}）。",
            f"本页基础底色：{page['background']['color']}；覆盖画布外层、素材周围衬底、间隙和文字说明区。",
            "局部背景例外：" + json.dumps(page["background"].get("regions", []), ensure_ascii=False),
            "背景颜色以结构化定稿为准，模板图底色由定稿色值替换，不自行选色；未列为例外的背景区域使用基础底色，保持纯色，不加渐变、纹理或花哨装饰；真实素材自身颜色保持原貌。",
        ])
        lines.append('仅软件步骤类 steps：在调研、选材和逐页规划阶段就从第一步（实际入口）开始，尽量清楚展示每一步及状态衔接；每张截图只对应一句描述当前单个操作的说明，不跳过第一步或关键动作。截图优先寻找或实际采集真实简体中文界面，不使用繁体中文，也不把英文界面原样作为交付截图。简单英文界面可准确翻译成简体中文：文案端在素材 description 及本页 layout 中记录原文、对应译文和位置，保持按钮位置、功能、数值、图标与操作关系不变，不添加原界面没有的操作或状态；生图端只执行已定稿的翻译，不自行猜译或改写功能，不额外添加“示意图”字样。无法准确翻译的界面继续寻找中文素材或在实际软件中切换简体中文后截图；关键步骤缺图时继续多渠道查找或实际操作截图，仍无法准确说明则记录具体缺口并标记 needs_input，不编造界面或把缺失流程交为完整教程。以上在生图前落实，不新增成图后的专项检查；non_steps（含 operation_guide）规则不变。')
        lines.append('仅 task_type: steps 的新增可见文字限定为第一页的主题标题，以及每张教程截图对应的简短操作说明。每条图上步骤说明必须对应本页实际呈现的真实截图，并由该截图支持所述操作；没有相应截图的步骤不写图上说明，不用无关截图配文字，不凭空生成界面或用纯文字补步骤。缺图先补找可靠素材；缺口影响流程可操作性时退回补料或标记 needs_input，不把不完整流程当成完整教程交付。第二页起不再添加标题；不添加副标题、版本信息、适用范围、适用条件、平台标签、页码、总结、提示或其他多余文字。版本与适用情况只用于内部调研核验，不印到图上，也不嵌入步骤说明；真实软件截图内原有界面文字默认保持原样，仅允许按已定稿方案准确翻译英文为简体中文，或按截图年份规则作指定局部处理，不改变功能或操作关系。保留必要操作箭头与定位框，操作说明写清动作及按钮或对象即可。此限制不改变 non_steps（含 operation_guide）的文字结构。')
        lines.append("本页为第一页：允许主题标题及截图操作说明。" if page["page"] == 1 else "本页不是第一页：只允许截图操作说明，不添加标题。")
        first_material = 2
    elif travel_route:
        validate_travel_page(page)
        lines.extend(['旅游景点路线、景点推荐采用 task_type: non_steps、content_kind: travel_route 专用摄影拼图，不套软件 steps 或游戏 operation_guide。每张路线拼图恰好四张不同的、已经核实地点的真实实景照片，优先参考满幅2×2四格、窄拼接缝、不加卡片框或大留白；可用原生网格裁切拼接以保留真实摄影，不用 AI 重建地标、假造景色或把同一照片不同裁切当不同素材。每格配贴近照片下缘的短地名/必要顺序号，高对比且避开主体；只有第一页顶部可放主题标题，后续页不重复标题。图与图之间用三条方向明确的箭头连接实际路线顺序，默认左上1→右上2→右下3→左下4蛇形，若实际路线要求另一布局则在 layout 和 annotations 中明确起终点，不能按装饰随意画反。跨页顺序连续；每格在 layout 绑定 image_id、实际地点、视角及路线节点，annotations 用起点图 image_id 与 arrow，target 写清目标图ID、起终位置和顺序。每页实际四照片，不以四个文件名或虚构景点凑数。景点不足四个或数量不整除时，可用同一路线上有依据的不同真实细节/视角填足四格，并明确它是同一景点的细节而非新增到访点；不得重复照片、虚构行程或塞无关图。整题仍2–18页，先统筹路线与不同真实素材；无法满足时补找或记录具体缺口，不交假完整稿。', '旅游正文保留自然引言，逐景点讲清推荐理由及路线所需信息，包含经实际来源核实的门票价格和开放时间；免费、免门票或开放式公共区域也必须核实，不能从未查到价格/时间推断免费或全天开放。明确币种（通常当地货币）、票种、适用区域及必要季节/日期条件，避免把外部自由通行与收费内区混为一谈；闭馆日、最后入场等必要条件融入对应景点。sources/references、reference_images.description 或现有调研交接记录保存支持依据、来源网址及核验日期，不新增杜撰价格或时间。缺可靠数据先补查，仍不足记录具体缺口，不把样例价格营业时间复制到新稿。正文不声称亲测/亲自到访，不追加结尾总结、提醒或延伸；样例仅学表达和版式，不是新文章任务。图上仅短景点名、顺序号、必要极简说明与路线箭头，不把正文的价格时间大段搬入四格，不为凑字加长文。', 'travel_route 是照片主导的类别例外：优先完整保留地标真实性和四格构图，照片可按布局裁去无关边缘但不可误导地点；原有普通 non_steps 的每页至少50字、推荐优缺点标签、背景必须浅色非白及 AI 场景融合/重绘要求不套到此类别，不能给实景换成生成背景。允许真实照片自身天空、夜色等自然颜色，文字保持可读；每格约四分之一，仍符合单主体含容器不超过三分之一的上限。底部用已有短地名标签、保持安全边距，不专门生成填充物。除该旅游例外外，车辆价格、普通非步骤、软件步骤和游戏规则全部保持。任务选择阶段既有景点大类排除如仍启用，由选择技能独立执行；本制作规则不修改筛选/删除规则，也不擅自新增或领取任务。', '既有文案和文字/实质复查内核对：每页四张不同真实照片及地名对应、三条路线连接方向与跨页顺序、简短标签和首图标题规则、正文门票币种与开放时间有依据；缺图或资料冲突退回文案，不自行补造。无新检查轮次，不修改冻结批次、用户电脑或历史输出。'])
        first_material = 1
    else:
        lines.extend([
            "按 layout 的内容顺序和图文对应关系制作，保持定稿文字、实际参考素材数量与分页。可自主调整构图、素材呈现方式、光影、间距和对齐，将参考内容融入精美、连贯的整体画面。",
            "插图与对应知识点及说明相邻，可穿插、错落或成组比较；用大小对比和图文呼应形成层次，相关说明连贯集中。按实际素材安排图文，不硬凑多图、重复素材或无意义装饰，不套单张大截图加几条字、重复等宽大白卡的固定版式。",
            ("本页无参考图，沿用纯小说纯文字页定稿，以统一色调安排柔和背景，不虚构具象内容。" if pure_novel and not page["image_ids"] else "全部输入图均为本页实际素材参考。参考原图重绘、提取主体或关键细节，协调色彩、材质、光线和边缘过渡，自然融入整体画面，无需保留原截图的矩形外框。保留人物、装备、NPC、物品及其他讲解对象的准确身份、可辨认外观和关键细节；需要展示的文字、数值、按钮、HUD 与空间关系保持准确清晰。按讲解需要保留完整画面或选取关键区域。"),
        ])
        if operation_guide:
            lines.extend([
                'operation_guide（游戏及非游戏）每个独立步骤图连同直接承载底板或容器不超过画布三分之一，逐个计算，不是全部配图合计；同一图的组成部分整体计算。普通 non_steps 原有同样面积上限不变。看不清时选择更清晰的真实素材或重新规划图文与分页，不突破面积上限；此面积规则与单图模板豁免是不同约束，既有单图模板适用范围不变。软件 steps 不套三分之一上限，仍用完整截图、每页最多两张、每张一句说明紧接其下方。',
                "本题为非软件操作教程，必须直接教具体做法，不能改成概念介绍、特点罗列或泛泛建议；不套软件步骤模板。参考重绘同样适用。依照 layout 和 text_blocks 呈现指定动作、顺序、入口与结果，操作图和对应说明相邻、顺序连贯；图幅以关键动作、文字、按钮、HUD与空间关系清楚可读为准。annotations 指向实际操作对象。",
                "游戏攻略只呈现定稿的必要关键节点，连续走路、普通跳跃和重复移动沿用概括说明；非游戏操作教程保留定稿的完整操作序列及各步素材内容，仅执行文案端记录的缺图精简安排。",
                "背景不使用单一平涂纯色，按主题安排明亮柔和的场景与自然光影层次。",
            ])
        else:
            lines.extend([
                "按实际语义标题组织完整信息区，解释、依据、对比或细节在对应区连贯呈现；有图时围绕素材安排文字，无图时文字自然利用可用空间，不预留固定空图位或空栏。标题适度，为正文留足空间。",
                "单个讲解主体连同其直接承载底板或容器不超过画布三分之一，即使放在背景层也如此；同一主体的组成部分整体计算，多个独立素材分别计算，并非全部配图的合计面积上限。连续底色、纹理、光影及主题氛围场景不计入讲解主体。",
            ])
        lines.append(f"整题统一色调：{color_theme}；背景明亮浅色且明显非白，配色丰富柔和，主色、辅助色和过渡色自然铺展，通过冷暖与明暗变化呈现清晰层次；不大面积使用高饱和颜色，文字清楚。")
        if not (pure_novel and not page["image_ids"]):
            lines.append(
                ("可围绕主题生成明亮、柔和的背景场景及相关元素，无需为氛围元素逐一提供参考图；背景与素材统一设计，不抢主体和文字，不将生成的氛围场景当作游戏真实场景、界面或准确讲解对象。" if pure_novel else
                 "可围绕主题生成明亮、柔和的背景场景及相关元素；通用桌椅、植物、生活物件等辅助元素可在前景、中景或背景自由生成，无需逐一提供参考图，不限于背景层。主题需要的无特定身份示意人物也可生成，人脸表现按 layout 定稿并沿用普通人脸规则。生成元素与参考素材统一设计，不抢主体和文字；真实具体人物、商品型号、游戏角色、装备、NPC、物品、界面及需准确展示的场景仍以实际参考素材为依据。")
                + "按内容需要组织前、中、后景，用自然柔和的方向光、材质高光、接触阴影和远近虚实拉开层次；场景细节服务主题，不堆无关装饰，文字区保持简洁。"
            )
        lines.append('非步骤类 non_steps（含 operation_guide）禁止用 AI 生成、重绘或拼造手机界面，也不生成类似手机界面的仿 UI、假截图或界面装饰。需要展示手机界面时，只使用本页映射的完整真实手机截图，像软件步骤图一样平直、等比例贴入版面，保留真实界面内容与矩形边界，不提取局部重绘，不添加手机机身或外壳。找不到合适的完整真实截图，就不展示手机界面，改用其他相关真实素材组织图文；缺口影响准确讲解时按原有补料流程处理。此规则优先于 non_steps 的素材重绘、关键区域提取、整体融合及通用辅助元素生成许可；其他真实实物图、游戏图等沿用原有规则。不新增成图后的专项检查。')
        first_material = 1
    lines.append(f"本页布局：{page['layout']}")
    for index, image_id in enumerate(page["image_ids"], first_material):
        item = reference_map[image_id]
        lines.append(f"输入图{index}，素材 {image_id}：{item['description']}")
        face_plan = validate_face_plan(item)
        if not face_plan:
            lines.append(f"素材 {image_id}：文案端已核对，无需素人人脸处理；球星、运动员等按 description 与 layout 定稿保留真实面容和素材。")
        for face in face_plan:
            method = "裁去指定边缘区域" if face["action"] == "crop" else "仅把指定脸部局部改为不对应真人身份的动漫脸"
            lines.append(f"素材 {image_id} 已定稿人脸动作：{method}；位置及范围：{face['target']}；必须保留：{face['preserve']}。")
    lines.append("以下为本页全部新增可见文字，按指定位置及样式排版：")
    lines.extend(json.dumps(block, ensure_ascii=False) for block in page["text_blocks"])
    lines.append("标注计划：" + json.dumps(page.get("annotations", []), ensure_ascii=False))
    lines.append("文字清晰，完整显示；本次仅制作定稿中的这一页。")
    return "\n".join(lines)


def validate_copy(data, folder, *, assembled=True):
    require(isinstance(data, dict), "文案结果应为对象")
    task = identity(folder)
    for key, value in task.items():
        require(data.get(key) == value, f"{key} 与任务输入不一致")
    require(data.get("schema_version") == 1, "schema_version 应为 1")
    if data.get("status") == "failed":
        require(all(isinstance(data.get(k), str) and data[k].strip()
                    for k in ("error_code", "error_message")), "失败结果应有原因和说明")
        return data
    require(data.get("status") == "completed", "文案状态应为 completed 或 failed")
    require(data.get("delivery_mode") == "posters", "delivery_mode 应为 posters")
    titles = data.get("titles")
    require(isinstance(titles, list) and len(titles) == 1 and isinstance(titles[0], str),
            "titles 应包含一个标题")
    question = re.split(r"[？?]", titles[0], maxsplit=1)
    require(len(question) == 2 and all(part.strip() for part in question),
            "标题采用具体问题＋留有悬念的回应")
    body = normalize_body(data.get("body_copy"))
    require(body == data["body_copy"], "正文空行应先归一化后发布")
    count = sum(not char.isspace() for char in body)
    require(400 <= count <= 600, f"正文为 {count} 个非空白字符，应为 400–600")
    require(isinstance(data.get("related_link"), str)
            and re.match(r"^https?://[^\s/]+", data["related_link"]), "需要参考内容页网址")
    pure_novel = data.get("task_type") == "non_steps" and data.get("content_kind") == "pure_novel"
    references = data.get("reference_images")
    require(isinstance(references, list) and (references or pure_novel), "需要已落盘的实际图片或截图")
    ids = set()
    reference_digests = {}
    for item in references:
        require(isinstance(item, dict), "素材应为对象")
        image_id = item.get("id")
        require(isinstance(image_id, str) and image_id.strip() and image_id not in ids,
                "素材 id 应非空且唯一")
        ids.add(image_id)
        validate_face_plan(item)
        require(isinstance(item.get("description"), str) and item["description"].strip(),
                "需要素材内容说明")
        source_url, capture_note = item.get("source_url"), item.get("capture_note")
        require((isinstance(source_url, str) and re.match(r"^https?://[^\s/]+", source_url))
                or (isinstance(capture_note, str) and capture_note.strip()),
                "素材应有来源页网址或截图记录")
        path = local_file(folder, item.get("local_path"))
        reference_digests[image_id] = sha256(path)
        if assembled:
            require(item.get("sha256") == reference_digests[image_id],
                    f"素材内容发生变化：{image_id}")
    pages = data.get("pages")
    require(isinstance(pages, list) and len(pages) >= MIN_POSTER_PAGES,
            f"每个主题至少需要 {MIN_POSTER_PAGES} 页制作稿，对应至少 {MIN_POSTER_PAGES} 张图片")
    used_image_ids = {}
    used_image_digests = {}
    for number, page in enumerate(pages, 1):
        require(isinstance(page, dict) and page.get("page") == number, "页码应从 1 连续编号")
        image_ids = page.get("image_ids")
        require(isinstance(image_ids, list) and (image_ids or pure_novel)
                and all(isinstance(i, str) and i in ids for i in image_ids), "页面素材映射不完整")
        if not assembled:
            for image_id in image_ids:
                require(image_id not in used_image_ids,
                        f"素材 {image_id} 已用于第{used_image_ids.get(image_id)}页；每项素材只能分配给一页")
                digest = reference_digests[image_id]
                require(digest not in used_image_digests,
                        f"素材 {image_id} 与第{used_image_digests.get(digest)}页使用了同一原图")
                used_image_ids[image_id] = number
                used_image_digests[digest] = number
        require(isinstance(page.get("layout"), str) and page["layout"].strip(),
                "文案阶段应确定本页图位、背景、文字位置和构图")
        blocks = page.get("text_blocks")
        require(isinstance(blocks, list) and blocks, "文案阶段应提供全部上图文字")
        for block in blocks:
            require(isinstance(block, dict)
                    and all(isinstance(block.get(k), str) and block[k].strip()
                            for k in ("text", "placement")), "文字块需要 text 和 placement")
        if data.get("content_kind") == "travel_route":
            validate_travel_page(page)
        annotations = page.get("annotations", [])
        require(isinstance(annotations, list), "annotations 应为数组")
        for annotation in annotations:
            require(isinstance(annotation, dict) and annotation.get("image_id") in image_ids
                    and annotation.get("kind") in {"arrow", "ellipse", "rectangle"}
                    and isinstance(annotation.get("target"), str) and annotation["target"].strip(),
                    "标注应指定本页素材、形状及实际操作对象")
        if assembled and data.get("task_type") == "steps":
            path = local_file(folder, page.get("template_path"))
            require(page.get("template_sha256") == sha256(path), "模板文件与交付不一致")
    validate_task_design(data)
    if assembled:
        expected = [page_prompt(page, references, data["task_type"],
                                background=data.get("background"), color_theme=data.get("color_theme"),
                                content_kind=data.get("content_kind")) for page in pages]
        # Backward compatibility only for the explicitly retired screenshot decoration clause.
        def canonical_prompts(values):
            return [v.replace('截图四周加细窄描边和轻微投影，操作箭头与定位框保持清楚；', '真实软件界面保持矩形，平直直接贴在背景上，不添加手机外壳、手机外框、描边、投影或其他装饰；保留必要操作箭头与定位框；').replace('截图不新增描边或投影，操作箭头与定位框保持清楚；', '真实软件界面保持矩形，平直直接贴在背景上，不添加手机外壳、手机外框、描边、投影或其他装饰；保留必要操作箭头与定位框；') for v in values] if isinstance(values, list) else values
        require(canonical_prompts(data.get("image_prompts")) == canonical_prompts(expected), "完整图片提示词应与文案端制作稿一致")
    return data


def invalidate_final(folder):
    path = Path(folder).parent / ".workflow/final_stage.json"
    path.unlink(missing_ok=True)


def request_backup(folder, event):
    """Per-topic outbox marker; local completion never means remote backup succeeded."""
    folder = Path(folder)
    record = {**identity(folder), "event": event, "remote_status": "pending"}
    for name in ("copy_result.json", "poster_result.json"):
        path = folder / ".workflow" / name
        if path.is_file():
            record[name + "_sha256"] = sha256(path)
    write_json(folder / ".workflow/backup_pending.json", record)


def validate_page_text_density(data):
    """Check authored visible information, not image prompts or screenshots."""
    if data.get("task_type") == "steps" or data.get("content_kind") in {"operation_guide", "travel_route"}:
        return
    title = data["titles"][0].strip()
    for number, page in enumerate(data["pages"], 1):
        chunks = []
        for block in page["text_blocks"]:
            for line in block["text"].splitlines():
                line = line.strip()
                if line == title:
                    continue
                chars = re.findall(r"[\w]", line, flags=re.UNICODE)
                # Short standalone headings, labels and numbering are not detail.
                if len(chars) > 8:
                    chunks.extend(chars)
        require(len(chunks) >= 50,
                f"第{number}页有效正文 {len(chunks)} 字符，不足50；补充具体信息并复核，勿凑字")


def publish(draft_path, replace=False):
    draft_path = Path(draft_path).resolve()
    require(draft_path.parent.name == ".workflow", "草稿应放在主题的 .workflow 目录")
    folder = draft_path.parent.parent
    target = folder / ".workflow/copy_result.json"
    require(replace or not target.exists(), "已发布文案；修订任务使用 publish --replace")
    task = identity(folder)
    data = {"schema_version": 1, **task, "status": "completed",
            "delivery_mode": "posters", **read_json(draft_path)}
    require(data["status"] == "completed", "publish 用于成功文案，终止主题使用 fail")
    data["body_copy"] = normalize_body(data.get("body_copy"))
    validate_copy(data, folder, assembled=False)
    validate_page_text_density(data)
    for item in data["reference_images"]:
        item["sha256"] = sha256(local_file(folder, item["local_path"]))
    if data["task_type"] == "steps":
        relative = ".workflow/templates/steps.png"
        destination = folder / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(SKILL / "assets/templates/steps.png", destination)
        for page in data["pages"]:
            page["template_path"] = relative
            page["template_sha256"] = sha256(destination)
    data["image_prompts"] = [page_prompt(page, data["reference_images"], data["task_type"],
                                        background=data.get("background"), color_theme=data.get("color_theme"),
                                        content_kind=data.get("content_kind"))
                             for page in data["pages"]]
    validate_copy(data, folder)
    invalidate_final(folder)
    write_json(folder / ".workflow/poster_result.json",
               {"schema_version": 1, **task, "status": "pending", "pages": []})
    write_json(target, data)
    request_backup(folder, "copy_published")
    return {"published": True, **task, "result": str(target), "pages": len(data["pages"]),
            "backup_required": True}


def fail(folder, code, message):
    folder = Path(folder).resolve()
    data = {"schema_version": 1, **identity(folder), "status": "failed",
            "error_code": code, "error_message": message}
    validate_copy(data, folder)
    require(not (folder / ".workflow/copy_result.json").exists(),
            "已有文案结果；先核对现有内容，再按修订任务处理")
    invalidate_final(folder)
    write_json(folder / ".workflow/copy_result.json", data)
    request_backup(folder, "copy_failed")
    return data


def status(root, run_id=None):
    root = Path(root).resolve()
    data = manifest(root)
    require(run_id is None or data["run_id"] == run_id, "运行号与固定批次不一致")
    results = []
    for entry in data["topics"]:
        folder = root / entry["folder_name"]
        record = dict(entry, folder=str(folder), state="pending_copy", copy_status="pending")
        copy_path = folder / ".workflow/copy_result.json"
        try:
            if copy_path.exists():
                record["copy_sha256"] = sha256(copy_path)
                copy = validate_copy(read_json(copy_path), folder)
                record["copy_status"] = copy["status"]
                if copy["status"] == "failed":
                    record.update(state="failed", reason=copy["error_code"])
                else:
                    record["state"] = "copy_ready"
                    poster_path = folder / ".workflow/poster_result.json"
                    if poster_path.exists():
                        poster = read_json(poster_path)
                        require(poster.get("run_id") == data["run_id"], "生图运行号不一致")
                        if poster.get("status") in {"completed", "failed"}:
                            require(poster.get("copy_sha256") == sha256(copy_path),
                                    "生图结果与当前文案不一致")
                            if poster["status"] == "completed":
                                record["state"] = "poster_ready"
                            else:
                                require(poster.get("error_code"), "生图失败缺少原因")
                                record.update(state="failed", reason=poster["error_code"])
            results.append(record)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            if record["copy_status"] == "pending" and copy_path.exists():
                record["copy_status"] = "invalid"
            results.append(dict(record, state="invalid", error=str(exc)))
    return {"run_id": data["run_id"], "root": str(root), "topics": results,
            "can_finalize": all(item["state"] in {"poster_ready", "failed"} for item in results)}


def dispatch_plan(report, stage, active=(), held=()):
    """Select available work; agent lifecycle and actual dispatch belong to the parent."""
    require(stage in {"copy", "render"}, "阶段应为 copy 或 render")
    active, held = set(active), set(held)
    require(len(active) <= 3, "每个主会话最多同时运行 3 个子代理")
    topics = report["topics"]
    known = {item["topic_id"] for item in topics}
    require((active | held).issubset(known), "活动或待补主题不属于当前批次")
    eligible = [item for item in topics
                if item["topic_id"] not in active | held
                and ((stage == "copy" and item["state"] == "pending_copy")
                     or (stage == "render" and item["state"] == "copy_ready"))]
    capacity = 3 - len(active)
    counts = {"total": len(topics), "active": len(active), "queued": len(eligible),
              "held": len(held), "invalid": sum(item["state"] == "invalid" for item in topics)}
    if stage == "copy":
        counts.update(completed=sum(item.get("copy_status") == "completed" for item in topics),
                      failed=sum(item.get("copy_status") == "failed" for item in topics),
                      pending=sum(item.get("copy_status") == "pending" for item in topics))
    else:
        counts.update(completed=sum(item["state"] == "poster_ready" for item in topics),
                      failed=sum(item["state"] == "failed" for item in topics),
                      pending=sum(item["state"] == "pending_copy" for item in topics))
    tasks = [dict(item, task_path=str(Path(item["folder"]) / ".workflow/task.json"),
                  draft_path=str(Path(item["folder"]) / ".workflow/copy_draft.json"),
                  copy_result=str(Path(item["folder"]) / ".workflow/copy_result.json"))
             for item in eligible[:capacity]]
    return {"run_id": report["run_id"], "root": report["root"], "stage": stage,
            "available_slots": capacity, "counts": counts, "dispatch": tasks,
            "can_finalize": report["can_finalize"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    create = commands.add_parser("init")
    create.add_argument("--root", type=Path, default=Path.home() / "图文创建")
    source = create.add_mutually_exclusive_group(required=True)
    source.add_argument("--topics-file", type=Path)
    source.add_argument("--topic")
    publish_parser = commands.add_parser("publish")
    publish_parser.add_argument("--draft", type=Path, required=True)
    publish_parser.add_argument("--replace", action="store_true")
    check = commands.add_parser("check")
    check.add_argument("--input", type=Path, required=True)
    failed = commands.add_parser("fail")
    failed.add_argument("--folder", type=Path, required=True)
    failed.add_argument("--code", required=True)
    failed.add_argument("--message", required=True)
    for name in ("status", "queue"):
        state = commands.add_parser(name)
        state.add_argument("--root", type=Path, required=True)
        state.add_argument("--run-id")
        if name == "queue":
            state.add_argument("--active-topic", action="append", default=[])
            state.add_argument("--hold-topic", action="append", default=[])
    args = parser.parse_args()
    try:
        if args.command == "init":
            topics = ([line.strip() for line in args.topics_file.read_text(encoding="utf-8-sig").splitlines()
                       if line.strip()] if args.topics_file else [args.topic])
            result = init(args.root, topics)
        elif args.command == "publish":
            result = publish(args.draft, args.replace)
        elif args.command == "check":
            validate_copy(read_json(args.input), args.input.resolve().parent.parent)
            result = {"valid": True, "input": str(args.input.resolve())}
        elif args.command == "fail":
            result = fail(args.folder, args.code, args.message)
        elif args.command == "queue":
            result = dispatch_plan(status(args.root, args.run_id), "copy",
                                   args.active_topic, args.hold_topic)
        else:
            result = status(args.root, args.run_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({"valid": False, "error": str(exc)}, ensure_ascii=False))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
