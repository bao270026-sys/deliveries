﻿param([string]$Destination = (Join-Path $HOME '.agents\skills'))
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force -Path $Destination | Out-Null
$Backup = Join-Path (Split-Path $Destination -Parent) ('openvam-backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
foreach ($Name in @('openvam-copy','openvam-render')) {
  $Source = Join-Path (Join-Path $PSScriptRoot 'skills') $Name
  if (!(Test-Path (Join-Path $Source 'SKILL.md'))) { throw "Missing skill: $Name" }
  $Target = Join-Path $Destination $Name
  if (Test-Path $Target) {
    New-Item -ItemType Directory -Force -Path $Backup | Out-Null
    Move-Item -LiteralPath $Target -Destination (Join-Path $Backup $Name)
  }
  Copy-Item -LiteralPath $Source -Destination $Target -Recurse
}
Write-Host "Installed two skills to: $Destination"
Write-Host "Existing same-name skills, if any, preserved at: $Backup"
