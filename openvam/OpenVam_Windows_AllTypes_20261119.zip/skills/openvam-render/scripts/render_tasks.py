#!/usr/bin/env python3
"""Read published copy, save generated posters, and finalize a local OpenVam batch."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import time

from PIL import Image

def find_copy_skill():
    """Resolve the active personal skill after installation renames directories."""
    root = Path(__file__).resolve().parents[2]
    candidates = []
    for folder in root.iterdir():
        front = folder / "SKILL.md"
        if not front.is_file():
            continue
        lines = front.read_text(encoding="utf-8").split("---", 2)
        if len(lines) >= 3 and any(line.strip() in
                {"name: openvam-copy", 'name: "openvam-copy"', "name: 'openvam-copy'"}
                for line in lines[1].splitlines()):
            candidates.append(folder)
    if len(candidates) != 1:
        raise ImportError("Expected one active openvam-copy skill; found " + str(len(candidates)))
    return candidates[0]

COPY_SKILL = find_copy_skill()
sys.path.insert(0, str(COPY_SKILL / "scripts"))
import copy_tasks as contract


def load_copy(path):
    path = Path(path).resolve()
    folder = path.parent.parent
    data = contract.read_json(path)
    return path, folder, data


def identity(data):
    return {key: data[key] for key in ("run_id", "topic_id", "topic")}


def state_for(path, folder, data):
    state_path = folder / ".workflow/poster_result.json"
    saved = contract.read_json(state_path) if state_path.exists() else {}
    state = {"schema_version": 1, **identity(data), "status": saved.get("status", "pending"),
             "copy_sha256": contract.sha256(path),
             "pages": [dict(item) for item in saved.get("pages", [])]}
    for key in ("error_code", "error_message", "failed_page"):
        if key in saved:
            state[key] = saved[key]
    return state


def page_task(copy_path, number):
    path, folder, data = load_copy(copy_path)
    contract.require(1 <= number <= len(data["pages"]), "页码超出本主题制作稿")
    page = data["pages"][number - 1]
    reference_map = {item["id"]: item for item in data["reference_images"]}
    paths = ([str((folder / page["template_path"]).resolve())]
             if data["task_type"] == "steps" else [])
    paths.extend(str((folder / reference_map[i]["local_path"]).resolve())
                 for i in page["image_ids"])
    state = state_for(path, folder, data)
    output = folder / f"海报_{number:02d}.png"
    saved = next((item for item in state["pages"] if item["page"] == number), None)
    already_saved = bool(saved and output.is_file())
    return {**identity(data), "task_type": data["task_type"], "content_kind": data.get("content_kind"), "page": number, "total_pages": len(data["pages"]),
            "prompt": data["image_prompts"][number - 1], "referenced_image_paths": paths,
            "text_blocks": page["text_blocks"], "output": str(output),
            "copy_sha256": contract.sha256(path), "already_saved": already_saved}


def image_info(path):
    path = Path(path)
    contract.require(path.is_file(), f"图片文件不存在：{path}")
    try:
        with Image.open(path) as image:
            contract.require(image.format == "PNG", f"图片必须为 PNG：{path.name}")
            image.verify()
        with Image.open(path) as image:
            image.load()
            width, height = image.size
            contract.require(width * 4 == height * 3,
                             f"图片应为严格竖版 3:4，实际为 {width}×{height}")
            contract.require(getattr(image, "n_frames", 1) == 1, "海报应为静态 PNG")
            contract.require(image.convert("RGBA").getchannel("A").getextrema() == (255, 255),
                             "图片应完全不透明")
    except (OSError, SyntaxError) as exc:
        raise ValueError(f"图片无法完整解码：{path.name}：{exc}") from exc
    return {"width": width, "height": height, "sha256": contract.sha256(path)}


def validate_delivery(folder, data, state):
    contract.require(len(data["pages"]) >= contract.MIN_POSTER_PAGES,
                     f"每个主题至少需要 {contract.MIN_POSTER_PAGES} 张图片才能完成交付")
    expected = list(range(1, len(data["pages"]) + 1))
    contract.require(expected and [page["page"] for page in data["pages"]] == expected,
                     "计划页码应从 1 连续编号")
    contract.require(len(data.get("image_prompts", [])) == len(expected), "计划页数与提示词不一致")
    pages = state.get("pages")
    contract.require(isinstance(pages, list)
                     and all(isinstance(item, dict) and type(item.get("page")) is int
                             for item in pages), "生图保存记录应包含整数页码")
    contract.require(sorted(item["page"] for item in pages) == expected,
                     f"图片未完整交付：应为 {expected}，实际为 {[item['page'] for item in pages]}")
    checked = []
    for item in sorted(pages, key=lambda item: item["page"]):
        filename = f"海报_{item['page']:02d}.png"
        contract.require(item.get("filename") == filename, f"第{item['page']}页文件名应为 {filename}")
        info = image_info(folder / filename)
        contract.require(not item.get("sha256") or item["sha256"] == info["sha256"],
                         f"图片内容与保存记录不一致：{filename}")
        checked.append({"page": item["page"], "filename": filename, **info})
    expected_files = {item["filename"] for item in checked}
    actual_files = {path.name for path in folder.glob("海报_*.png") if path.is_file()}
    contract.require(actual_files == expected_files,
                     f"海报文件与计划不一致，多余文件：{sorted(actual_files - expected_files)}")
    return checked


def save(copy_path, number, image_path):
    path, folder, data = load_copy(copy_path)
    contract.require(1 <= number <= len(data["pages"]), "页码超出本主题制作稿")
    image_path = Path(image_path).resolve()
    output = folder / f"海报_{number:02d}.png"
    state = state_for(path, folder, data)
    if image_path != output.resolve():
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(dir=folder, suffix=".png", delete=False) as stream:
                temporary = Path(stream.name)
            shutil.copy2(image_path, temporary)
            metadata = image_info(temporary)
            os.replace(temporary, output)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
    else:
        metadata = image_info(output)
    info = {"filename": output.name, "page": number, **metadata}
    state["pages"] = sorted([item for item in state["pages"] if item["page"] != number] + [info],
                            key=lambda item: item["page"])
    state.update(status="rendering", copy_sha256=contract.sha256(path))
    for key in ("error_code", "error_message", "failed_page"):
        state.pop(key, None)
    contract.invalidate_final(folder)
    contract.write_json(folder / ".workflow/poster_result.json", state)
    return {"saved": True, "page": number, "path": str(output), **info}


def finish(copy_path):
    path, folder, data = load_copy(copy_path)
    state = state_for(path, folder, data)
    state["pages"] = validate_delivery(folder, data, state)
    state.update(status="completed")
    contract.invalidate_final(folder)
    contract.write_json(folder / ".workflow/poster_result.json", state)
    if hasattr(contract, "request_backup"):
        contract.request_backup(folder, "poster_completed")
    return {"completed": True, **identity(data), "backup_required": True,
            "images": [str(folder / item["filename"]) for item in state["pages"]]}


def fail(copy_path, code, message, page=None):
    path, folder, data = load_copy(copy_path)
    contract.require(code.strip() and message.strip(), "失败结果需要具体原因")
    state = state_for(path, folder, data)
    state.update(status="failed", error_code=code, error_message=message)
    if page is not None:
        contract.require(1 <= page <= len(data["pages"]), "失败页码超出范围")
        state["failed_page"] = page
    contract.invalidate_final(folder)
    contract.write_json(folder / ".workflow/poster_result.json", state)
    if hasattr(contract, "request_backup"):
        contract.request_backup(folder, "poster_failed")
    return state


def status(root, run_id=None, skip_topics=()):
    root = Path(root).resolve()
    if not (root / ".workflow/run_manifest.json").exists():
        return {"root": str(root), "run_id": run_id, "state": "wait_for_copy_start",
                "topics": [], "can_finalize": False}
    manifest = contract.read_json(root / ".workflow/run_manifest.json")
    contract.require(run_id is None or manifest["run_id"] == run_id,
                     "运行号已变化；继续使用原先固定的 run_id")
    topics = []
    for entry in manifest["topics"]:
        folder = root / entry["folder_name"]
        record = dict(entry, folder=str(folder), state="pending_copy", copy_status="pending")
        copy_path = folder / ".workflow/copy_result.json"
        try:
            if copy_path.exists():
                data = contract.read_json(copy_path)
                record["copy_status"] = data.get("status", "pending")
                if record["copy_status"] == "failed":
                    record.update(state="failed", reason=data.get("error_code", "copy_failed"))
                elif record["copy_status"] == "completed":
                    record.update(state="copy_ready", copy_sha256=contract.sha256(copy_path))
                    poster_path = folder / ".workflow/poster_result.json"
                    if poster_path.exists():
                        poster = contract.read_json(poster_path)
                        if poster.get("status") == "completed":
                            validate_delivery(folder, data, poster)
                            record["state"] = "poster_ready"
                        elif poster.get("status") == "failed":
                            record.update(state="failed", reason=poster.get("error_code", "render_failed"))
        except (OSError, ValueError, KeyError, TypeError) as exc:
            record.update(state="input_error", error=str(exc))
        topics.append(record)
    report = {"run_id": manifest["run_id"], "root": str(root), "topics": topics,
              "can_finalize": all(item["state"] in {"poster_ready", "failed"} for item in topics)}
    skip_topics = set(skip_topics)
    states = [item["state"] for item in report["topics"] if item["topic_id"] not in skip_topics]
    if report["can_finalize"]:
        phase = "ready_to_finalize"
    elif "copy_ready" in states:
        phase = "render_ready"
    elif "input_error" in states or skip_topics:
        phase = "wait_for_input"
    else:
        phase = "wait_for_copy"
    return dict(report, state=phase)


def wait_for_work(root, run_id=None, seconds=30, skip_topics=()):
    """Wait for a bounded interval; timeout leaves the batch open for the agent loop."""
    contract.require(0 <= seconds <= 30, "单次等待应为 0–30 秒")
    started = time.monotonic()
    initial = status(root, run_id, skip_topics)
    pinned = initial.get("run_id")
    current = initial
    while current["state"] not in {"render_ready", "ready_to_finalize"}:
        remaining = seconds - (time.monotonic() - started)
        if remaining <= 0:
            return dict(current, wait_timed_out=True,
                        waited_seconds=round(time.monotonic() - started, 3))
        time.sleep(min(1.0, remaining))
        current = status(root, pinned, skip_topics)
        if pinned is None:
            pinned = current.get("run_id")
        if current != initial:
            break
    return dict(current, wait_timed_out=False,
                waited_seconds=round(time.monotonic() - started, 3))


def queue(root, run_id=None, active=(), held=()):
    report = status(root, run_id)
    plan = contract.dispatch_plan(report, "render", active, held)
    return dict(plan, state=report["state"])


def finalize(root, run_id=None):
    root = Path(root).resolve()
    report = status(root, run_id)
    contract.require(report["can_finalize"], "仍有待完成主题，请先读取 status")
    records = report["topics"]
    success = sum(item["state"] == "poster_ready" for item in records)
    result = {"schema_version": 1, "run_id": report["run_id"], "topics": records,
              "success": success, "failed": len(records) - success, "valid": success == len(records)}
    contract.write_json(root / ".workflow/final_stage.json", result)
    return dict(result, finalized=True, root=str(root))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("page", "save", "finish", "fail"):
        command = commands.add_parser(name)
        command.add_argument("--copy-result", type=Path, required=True)
        if name in {"page", "save"}:
            command.add_argument("--page", type=int, required=True)
        if name == "save":
            command.add_argument("--image", type=Path, required=True)
        elif name == "fail":
            command.add_argument("--code", required=True)
            command.add_argument("--message", required=True)
            command.add_argument("--page", type=int)
    for name in ("status", "queue", "wait", "finalize"):
        command = commands.add_parser(name)
        command.add_argument("--root", type=Path, required=True)
        command.add_argument("--run-id")
        if name == "wait":
            command.add_argument("--seconds", type=float, default=30)
            command.add_argument("--skip-topic", action="append", default=[])
        elif name == "queue":
            command.add_argument("--active-topic", action="append", default=[])
            command.add_argument("--hold-topic", action="append", default=[])
    args = parser.parse_args()
    try:
        if args.command == "page":
            result = page_task(args.copy_result, args.page)
        elif args.command == "save":
            result = save(args.copy_result, args.page, args.image)
        elif args.command == "finish":
            result = finish(args.copy_result)
        elif args.command == "fail":
            result = fail(args.copy_result, args.code, args.message, args.page)
        elif args.command == "status":
            result = status(args.root, args.run_id)
        elif args.command == "wait":
            result = wait_for_work(args.root, args.run_id, args.seconds, args.skip_topic)
        elif args.command == "queue":
            result = queue(args.root, args.run_id, args.active_topic, args.hold_topic)
        else:
            result = finalize(args.root, args.run_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({"valid": False, "error": str(exc)}, ensure_ascii=False))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
