#!/usr/bin/env python3
"""Offline, content-addressed checkpoints and portable OpenVam delivery packages.

Cloud transfers are deliberately performed by the authenticated Space connector,
not this script. A local snapshot is not a confirmed remote backup.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import tempfile
import zipfile

SCHEMA = "openvam-recovery-v1"


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")
        temporary = f.name
    os.replace(temporary, path)


def safe_name(name):
    require(isinstance(name, str) and name, f"Unsafe relative path: {name!r}")
    p = PurePosixPath(name)
    require(p.parts and p.as_posix() == name and not p.is_absolute()
            and ".." not in p.parts and "\\" not in name and ":" not in name,
            f"Unsafe relative path: {name!r}")
    return p


def manifest(root):
    m = read(Path(root) / ".workflow/run_manifest.json")
    require(m.get("workflow") == "openvam-pair-v1", "Unsupported batch workflow")
    require(isinstance(m.get("run_id"), str) and m["run_id"], "Missing run_id")
    require(len(safe_name(m["run_id"]).parts) == 1, "Unsafe run_id")
    require(isinstance(m.get("topics"), list) and m["topics"], "Empty batch")
    ids, folders = set(), set()
    for item in m["topics"]:
        name = item["folder_name"]
        require(len(safe_name(name).parts) == 1 and name not in folders, "Unsafe or duplicate topic folder")
        require(len(safe_name(item["topic_id"]).parts) == 1 and item["topic_id"] not in ids,
                "Unsafe or duplicate topic_id")
        require(item.get("relative_dir", name) == name, "Topic must be a direct child")
        folders.add(name)
        ids.add(item["topic_id"])
    return m


def file_tree(root):
    root = Path(root)
    require(not root.is_symlink(), f"Symlink not allowed: {root}")
    for p in sorted(root.rglob("*")):
        require(not p.is_symlink(), f"Symlink not allowed: {p}")
        if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc":
            yield p


def load_engine(skills):
    path = Path(skills) / "openvam-render/scripts/render_tasks.py"
    spec = importlib.util.spec_from_file_location("openvam_recovery_render", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    # Avoid an earlier batch's copy module surviving a second recovery in one process.
    sys.modules.pop("copy_tasks", None)
    spec.loader.exec_module(module)
    return module


def freeze(root, copy_skill, render_skill):
    """Pin code/assets once; never mutate an existing batch's frozen rules."""
    target = Path(root) / ".workflow/frozen_skills"
    if target.exists():
        require((target / "openvam-copy/scripts/copy_tasks.py").is_file(), "Incomplete frozen copy skill")
        require((target / "openvam-render/scripts/render_tasks.py").is_file(), "Incomplete frozen render skill")
        return target
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=target.parent) as tmp:
        stage = Path(tmp) / "frozen_skills"
        for label, source in (("openvam-copy", copy_skill), ("openvam-render", render_skill)):
            source = Path(source)
            require((source / "SKILL.md").is_file(), f"Missing skill: {source}")
            for path in file_tree(source):
                relative = path.relative_to(source)
                if relative.parts[0] in {"tests", ".git"} or relative.parts[:2] == ("assets", "examples"):
                    continue
                dst = stage / label / relative
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, dst)
        os.replace(stage, target)
    return target


def inspect_topic(root, item, engine):
    root = Path(root)
    folder = root / item["folder_name"]
    ident = engine.contract.identity(folder)
    require(ident["topic_id"] == item["topic_id"], "Topic identity mismatch")
    cp = folder / ".workflow/copy_result.json"
    result = dict(item, state="pending_copy", saved_pages=[])
    if not cp.exists():
        return result
    data = engine.contract.validate_copy(read(cp), folder)
    if data["status"] == "failed":
        return dict(result, state="failed", reason=data["error_code"])
    require(2 <= len(data["pages"]) <= 18, "Poster page count must be 2–18")
    result["state"] = "copy_ready"
    pp = folder / ".workflow/poster_result.json"
    if pp.exists():
        poster = read(pp)
        for key in ("run_id", "topic_id", "topic"):
            require(poster.get(key) == data[key], f"Poster {key} mismatch")
        if poster.get("status") != "pending" or poster.get("pages"):
            require(poster.get("copy_sha256") == digest(cp), "Poster belongs to another copy revision")
        seen = set()
        for page in poster.get("pages", []):
            number = page["page"]
            require(type(number) is int and 1 <= number <= len(data["pages"]) and number not in seen,
                    "Duplicate or invalid saved page")
            seen.add(number)
            require(page["filename"] == f"海报_{number:02d}.png", "Wrong poster filename")
            info = engine.image_info(folder / page["filename"])
            require(info["sha256"] == page.get("sha256"), "Saved poster hash mismatch")
        result["saved_pages"] = sorted(seen)
        if poster["status"] == "completed":
            engine.validate_delivery(folder, data, poster)
            result["state"] = "poster_ready"
        elif poster["status"] == "failed":
            require(poster.get("error_code"), "Failure must have a reason")
            result.update(state="failed", reason=poster["error_code"])
    return result


def snapshot(root, topic_id, out, copy_skill, render_skill):
    root, out = Path(root).resolve(), Path(out).resolve()
    require(not out.is_relative_to(root), "Keep checkpoint outbox outside the batch")
    m = manifest(root)
    items = [i for i in m["topics"] if i["topic_id"] == topic_id]
    require(len(items) == 1, "Unknown topic_id")
    skills = freeze(root, copy_skill, render_skill)
    state = inspect_topic(root, items[0], load_engine(skills))
    sources = {".workflow/run_manifest.json": root / ".workflow/run_manifest.json"}
    for p in file_tree(skills):
        sources[p.relative_to(root).as_posix()] = p
    for p in file_tree(root / items[0]["folder_name"]):
        sources[p.relative_to(root).as_posix()] = p
    records = {name: {"sha256": digest(path), "size": path.stat().st_size}
               for name, path in sources.items()}
    metadata = {"schema": SCHEMA, "run_id": m["run_id"], "topic_id": topic_id,
                "topic_state": state, "files": records}
    signature = hashlib.sha256(json.dumps(metadata, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    metadata["snapshot_id"] = signature
    out.mkdir(parents=True, exist_ok=True)
    final = out / f"OpenVam_{m['run_id']}_{topic_id}_{signature[:16]}.zip"
    if not final.exists():
        with tempfile.NamedTemporaryFile(dir=out, suffix=".zip", delete=False) as f:
            tmp = Path(f.name)
        try:
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
                for name, p in sources.items():
                    z.write(p, "payload/" + name)
                z.writestr("checkpoint.json", json.dumps(metadata, ensure_ascii=False, indent=2))
            verify(tmp)
            require(all(digest(p) == records[n]["sha256"] for n, p in sources.items()),
                    "Source changed during checkpoint; wait for worker and retry")
            os.replace(tmp, final)
        finally:
            tmp.unlink(missing_ok=True)
    require(verify(final)["snapshot_id"] == signature, "Checkpoint name collision")
    return {"status": "local_only", "path": str(final), "sha256": digest(final),
            "snapshot_id": signature, "run_id": m["run_id"], "topic_id": topic_id,
            "topic_state": state}


def verify(archive):
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        require(len(names) == len(set(names)), "Duplicate ZIP members")
        for i in z.infolist():
            safe_name(i.filename)
            require(not stat.S_ISLNK(i.external_attr >> 16), "ZIP symlink rejected")
        require("checkpoint.json" in names, "Missing checkpoint manifest")
        meta = json.loads(z.read("checkpoint.json"))
        require(meta.get("schema") == SCHEMA, "Unknown recovery schema")
        require(set(names) == {"checkpoint.json"} | {"payload/" + n for n in meta["files"]},
                "Unexpected/missing ZIP members")
        for name, rec in meta["files"].items():
            safe_name(name)
            info = z.getinfo("payload/" + name)
            require(info.file_size == rec["size"], f"Size mismatch: {name}")
            h = hashlib.sha256()
            with z.open(info) as f:
                for block in iter(lambda: f.read(1024 * 1024), b""):
                    h.update(block)
            require(h.hexdigest() == rec["sha256"], f"Hash mismatch: {name}")
        expected = meta.pop("snapshot_id")
        actual = hashlib.sha256(json.dumps(meta, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        require(expected == actual, "Snapshot identity mismatch")
        meta["snapshot_id"] = expected
        batch = json.loads(z.read("payload/.workflow/run_manifest.json"))
        require(batch.get("workflow") == "openvam-pair-v1"
                and batch.get("run_id") == meta["run_id"], "Checkpoint batch identity mismatch")
        selected = [i for i in batch["topics"] if i["topic_id"] == meta["topic_id"]]
        require(len(selected) == 1, "Checkpoint topic identity mismatch")
        item = selected[0]
        folder = item["folder_name"]
        require(len(safe_name(folder).parts) == 1, "Unsafe topic folder")
        require(all(meta["topic_state"].get(k) == item[k]
                    for k in ("topic_id", "topic", "folder_name")), "Checkpoint state identity mismatch")
        for name in meta["files"]:
            require(name == ".workflow/run_manifest.json"
                    or name.startswith(".workflow/frozen_skills/")
                    or name.startswith(folder + "/"), "Checkpoint contains another topic or unexpected file")
        marker = z.read("payload/" + folder + "/.workflow/run_id.txt").decode().strip()
        require(marker == meta["run_id"], "Checkpoint topic run marker mismatch")
        for filename in ("task.json", "copy_result.json", "poster_result.json"):
            name = folder + "/.workflow/" + filename
            if name in meta["files"]:
                record = json.loads(z.read("payload/" + name))
                require(record.get("run_id") == meta["run_id"]
                        and record.get("topic_id") == meta["topic_id"]
                        and record.get("topic") == item["topic"], "Checkpoint record identity mismatch")
        return meta


def commit(index, downloaded, library_file_id, file_id=None, file_name=None):
    """Record only a checkpoint fetched back from Space and verified byte-for-byte."""
    meta = verify(downloaded)
    require(library_file_id and isinstance(library_file_id, str), "Need real Space receipt ID")
    idx = read(index) if Path(index).exists() else {
        "schema": SCHEMA, "run_id": meta["run_id"], "generation": 0, "topics": {}}
    require(idx.get("schema") == SCHEMA and idx["run_id"] == meta["run_id"], "Index is for another batch")
    rec = {"library_file_id": library_file_id, "file_id": file_id,
           "file_name": file_name or Path(downloaded).name,
           "archive_sha256": digest(downloaded), "snapshot_id": meta["snapshot_id"],
           "topic_state": meta["topic_state"]}
    if idx["topics"].get(meta["topic_id"]) != rec:
        idx["topics"][meta["topic_id"]] = rec
        idx["generation"] += 1
        write(index, idx)
    return idx


def restore(index, archives, destination):
    idx, dest = read(index), Path(destination).resolve()
    require(idx.get("schema") == SCHEMA and idx.get("topics"), "Invalid or empty recovery index")
    require(not dest.exists() or (dest.is_dir() and not any(dest.iterdir())), "Restore only into an empty directory")
    by_hash = {digest(p): p for p in Path(archives).glob("*.zip")}
    checked = []
    for topic_id, rec in idx["topics"].items():
        require(rec["archive_sha256"] in by_hash, f"Missing archive for topic {topic_id}")
        p = by_hash[rec["archive_sha256"]]
        meta = verify(p)
        require(meta["run_id"] == idx["run_id"] and meta["topic_id"] == topic_id
                and meta["snapshot_id"] == rec["snapshot_id"], "Index/checkpoint mismatch")
        checked.append((p, meta))
    dest.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="openvam-restore-", dir=dest.parent) as temp:
        stage = Path(temp) / "batch"
        stage.mkdir()
        for p, meta in checked:
            with zipfile.ZipFile(p) as z:
                for relative, rec in meta["files"].items():
                    path = stage / relative
                    if path.exists():
                        require(digest(path) == rec["sha256"], f"Conflicting shared checkpoint file: {relative}")
                        continue
                    path.parent.mkdir(parents=True, exist_ok=True)
                    with z.open("payload/" + relative) as src, path.open("wb") as dst:
                        shutil.copyfileobj(src, dst)
        m = manifest(stage)
        engine = load_engine(stage / ".workflow/frozen_skills")
        for item in m["topics"]:
            folder = stage / item["folder_name"]
            if not folder.exists():
                (folder / ".workflow").mkdir(parents=True)
                write(folder / ".workflow/task.json", dict(item, run_id=m["run_id"]))
                (folder / ".workflow/run_id.txt").write_text(m["run_id"] + "\n")
            inspect_topic(stage, item, engine)
        write(stage / ".workflow/recovery_index.json", idx)
        if dest.exists():
            dest.rmdir()  # only the empty destination created for this restore
        os.replace(stage, dest)
    engine = load_engine(dest / ".workflow/frozen_skills")
    report = engine.status(dest, idx["run_id"])
    report["recovered_topics"] = sorted(idx["topics"])
    report["active_workers"] = []
    write(dest / ".workflow/recovery_report.json", report)
    return report


def index_artifact(index, out):
    """Create a new immutable index artifact; never replace a remote index in place."""
    source, out = Path(index), Path(out)
    idx = read(source)
    require(idx.get("schema") == SCHEMA and type(idx.get("generation")) is int
            and idx["generation"] > 0 and idx.get("topics"), "Invalid recovery index")
    safe_name(idx["run_id"])
    sha = digest(source)
    out.mkdir(parents=True, exist_ok=True)
    target = out / f"OpenVam_{idx['run_id']}_index_g{idx['generation']:06d}_{sha[:16]}.json"
    if target.exists():
        require(digest(target) == sha, "Index artifact collision")
    else:
        shutil.copy2(source, target)
    return {"status": "local_only", "path": str(target), "sha256": sha,
            "run_id": idx["run_id"], "generation": idx["generation"]}


def portable_checker():
    path = Path(__file__).parent / "delivery_preflight.py"
    spec = importlib.util.spec_from_file_location("openvam_delivery_preflight", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def delivery_files(root):
    """An explicit allowlist, never a recursive copy of the working batch."""
    root = Path(root)
    selected = {".workflow/run_manifest.json", ".workflow/final_stage.json"}
    for item in manifest(root)["topics"]:
        name = item["folder_name"]
        folder = root / name
        for filename in ("task.json", "run_id.txt", "copy_result.json", "poster_result.json", "text_check.json"):
            relative = f"{name}/.workflow/{filename}"
            if (root / relative).is_file():
                selected.add(relative)
        for filename in ("正文.txt", "标题.txt", "文案.txt", "正文文案.txt", "标题文案.txt"):
            if (folder / filename).is_file():
                selected.add(f"{name}/{filename}")
        copy = read(folder / ".workflow/copy_result.json")
        if copy["status"] == "completed":
            assets = [r["local_path"] for r in copy["reference_images"]]
            assets += [p["template_path"] for p in copy["pages"] if "template_path" in p]
            for relative in assets:
                safe_name(relative)
                require(not any(part in {"frozen_skills", "text_candidates", "backup_pending.json",
                                          "recovery_index.json", "recovery_report.json"}
                                for part in PurePosixPath(relative).parts), "Private file used as reference")
                selected.add(f"{name}/{relative}")
            poster = read(folder / ".workflow/poster_result.json")
            for page in poster.get("pages", []):
                selected.add(f"{name}/{page['filename']}")
    for name in sorted(selected):
        safe_name(name)
        path = root / name
        require(path.is_file() and not any(p.is_symlink() for p in [path, *path.parents]),
                "Missing file or symlink in delivery: " + name)
        yield name, path


def validate_final(root, relocate=False):
    root = Path(root).resolve()
    if not (root / ".workflow/frozen_skills").exists():
        return portable_checker().validate_final(root, relocate)
    sums = root / "SHA256.json"
    if sums.exists():
        for name, expected in read(sums).items():
            safe_name(name)
            # The only intentionally mutable final-package field is local stage paths.
            if name != ".workflow/final_stage.json":
                require(digest(root / name) == expected, f"Final package hash mismatch: {name}")
    m = manifest(root)
    engine = load_engine(root / ".workflow/frozen_skills")
    states = [inspect_topic(root, i, engine) for i in m["topics"]]
    require(all(i["state"] in {"poster_ready", "failed"} for i in states), "Batch is incomplete; no final package")
    stage = read(root / ".workflow/final_stage.json")
    require(stage["run_id"] == m["run_id"] and len(stage["topics"]) == len(states), "Invalid final stage")
    for item, actual in zip(stage["topics"], states):
        for key in ("topic_id", "topic", "folder_name", "state"):
            require(item.get(key) == actual[key], f"Final stage {key} mismatch")
        if actual["state"] == "failed":
            require(item.get("reason") == actual["reason"], "Failure reason mismatch")
        if relocate:
            item["folder"] = str(root / actual["folder_name"])
    require(stage["success"] == sum(i["state"] == "poster_ready" for i in states)
            and stage["failed"] == sum(i["state"] == "failed" for i in states), "Final counts mismatch")
    if relocate:
        write(root / ".workflow/final_stage.json", stage)
    return {"run_id": m["run_id"], "success": stage["success"], "failed": stage["failed"],
            "topics": states, "offline_integrity": "passed", "live_submission": "not_tested"}


def delivery(root, output):
    root, output = Path(root).resolve(), Path(output).resolve()
    require(not output.is_relative_to(root), "Final ZIP must be outside batch")
    report = validate_final(root)
    # Include a self-contained preflight. Never install or launch the user's submitter.
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent) as tmp:
        stage = Path(tmp) / root.name
        stage.mkdir()
        for relative, source in delivery_files(root):
            target = stage / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        checker = portable_checker()
        shutil.copy2(Path(__file__).parent / "delivery_preflight.py", stage / "提交前检查.py")
        launcher = Path(__file__).parent / "launch_package.py"
        if not launcher.is_file():
            launcher = root / "一键提交本包.py"
        require(launcher.is_file(), "Missing single-entry launcher")
        shutil.copy2(launcher, stage / "一键提交本包.py")
        (stage / "一键提交本包.sh").write_text(
            '#!/usr/bin/env bash\nset -euo pipefail\ncd -- "$(dirname -- "$0")"\n'
            'python3 "一键提交本包.py" --root "$PWD" "$@"\n', encoding="utf-8")
        (stage / "一键提交本包.sh").chmod(0o755)
        (stage / "提交前检查.sh").write_text(
            '#!/usr/bin/env bash\nset -euo pipefail\ncd -- "$(dirname -- "$0")"\n'
            'python3 "提交前检查.py" preflight --root "$PWD" --relocate\n', encoding="utf-8")
        (stage / "提交前检查.sh").chmod(0o755)
        (stage / "提交说明.txt").write_text(
            "解压后运行一键提交本包.sh；自动选择本目录，离线预检通过并确认后调用您现有的提交器。\n"
            "默认提交器为用户主目录/自动提交OpenVam.py；其他位置可传 --submitter <实际路径>。\n"
            "仅验证可运行：bash 一键提交本包.sh --check-only，不登录、不上传、不提交或放弃任务。\n"
            "原有一键提交入口也可使用：先运行提交前检查.sh，再选择本解压根目录。\n"
            "需要 Python 3 与 Pillow。桌面提交程序及浏览器登录仍使用您现有的安装。\n"
            "当前仅可宣称离线结构与哈希通过；桌面程序实际版本、页数上限和在线提交需另行验证。\n"
            "备份保持私有并保留，不随最终包发布或自动清理。\n", encoding="utf-8")
        checksums = {p.relative_to(stage).as_posix(): checker.file_hash(stage, p.relative_to(stage).as_posix())
                     for p in file_tree(stage) if p.name != "SHA256.json"}
        write(stage / "SHA256.json", checksums)
        checker.validate_final(stage, relocate=True)
        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as z:
            for p in file_tree(stage):
                z.write(p, root.name + "/" + p.relative_to(stage).as_posix())
    return dict(report, archive=str(output), sha256=digest(output))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    s = sub.add_parser("snapshot")
    for name in ("root", "topic-id", "out", "copy-skill", "render-skill"):
        s.add_argument("--" + name, required=True)
    s = sub.add_parser("verify")
    s.add_argument("archive")
    s = sub.add_parser("commit")
    for name in ("index", "downloaded", "library-file-id"):
        s.add_argument("--" + name, required=True)
    s.add_argument("--file-id")
    s.add_argument("--file-name")
    s = sub.add_parser("restore")
    for name in ("index", "archives", "destination"):
        s.add_argument("--" + name, required=True)
    s = sub.add_parser("index-artifact")
    s.add_argument("--index", required=True)
    s.add_argument("--out", required=True)
    s = sub.add_parser("preflight")
    s.add_argument("--root", required=True)
    s.add_argument("--relocate", action="store_true")
    s = sub.add_parser("delivery")
    s.add_argument("--root", required=True)
    s.add_argument("--output", required=True)
    args = vars(p.parse_args())
    command = args.pop("command")
    try:
        result = {"snapshot": snapshot, "verify": verify, "commit": commit,
                  "restore": restore, "index-artifact": index_artifact,
                  "preflight": validate_final, "delivery": delivery}[command](**args)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (ValueError, OSError, KeyError, TypeError, zipfile.BadZipFile) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
