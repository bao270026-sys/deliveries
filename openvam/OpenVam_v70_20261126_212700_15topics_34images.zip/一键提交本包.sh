#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 "一键提交本包.py" --root "$PWD" "$@"
