#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 "提交前检查.py" preflight --root "$PWD" --relocate
