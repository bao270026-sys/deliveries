#!/usr/bin/env python3
"""User-operated single entry point: offline checks, then existing OpenVam submitter.

Never run the submission branch while merely building or validating a package.
Use --check-only for automated tests. Credentials and browser setup stay with the
user's existing installation; this file never installs or replaces it.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import sys


def check(root, submitter):
    root, submitter = Path(root).resolve(), Path(submitter).expanduser().resolve()
    if not submitter.is_file():
        raise ValueError("未找到您现有的自动提交OpenVam.py；请用 --submitter 指定实际安装位置。")
    preflight = subprocess.run([sys.executable, str(root / "提交前检查.py"), "preflight",
                               "--root", str(root), "--relocate"],
                              check=True, capture_output=True, text=True)
    report = json.loads(preflight.stdout)
    sys.path.insert(0, str(submitter.parent))
    spec = importlib.util.spec_from_file_location("openvam_existing_submitter", submitter)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    for method in ("load_local_work", "load_batch_failures", "planned_content_check"):
        if not callable(getattr(module, method, None)):
            raise ValueError(f"现有提交器缺少离线校验入口 {method}，请先确认兼容版本。")
    failures = module.load_batch_failures(root)
    failed = {item.folder for item in failures}
    works = [item for item in module.load_local_work(root) if item.folder not in failed]
    if len(works) != report["success"] or len(failures) != report["failed"]:
        raise ValueError("提交器读取的成功/失败主题数量与本包不一致。")
    for work in works:
        errors, draft_reasons = module.planned_content_check(work)
        if errors or draft_reasons:
            raise ValueError(work.topic + "：" + "；".join(errors + draft_reasons))
    return {"root": str(root), "submitter": str(submitter), "success": len(works),
            "failed": len(failures), "failed_topics": [item.topic for item in failures],
            "offline_checks": "passed", "submission_executed": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--submitter", type=Path, default=Path.home() / "自动提交OpenVam.py")
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    try:
        result = check(args.root, args.submitter)
        if args.check_only:
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return
        print(f"本包离线检查通过：成功 {result['success']} 题，明确失败 {result['failed']} 题。")
        print("将调用您现有的提交程序，填写并提交 OpenVam 当前匹配任务；保持其原有参考网址检查。")
        if result["failed"]:
            print("请注意：原提交程序会按其既有规则处理以下失败任务，可能放弃网页任务并移入废纸篓：")
            print("、".join(result["failed_topics"]))
        print("本次操作不删除私有 Space 备份。请先确认您已在自己的浏览器登录正确账户。")
        if input("确认现在提交，请输入“提交”；其他输入取消：").strip() != "提交":
            print("已取消，未启动提交程序。")
            return
        command = [sys.executable, result["submitter"], "--root", result["root"], "--all", "--confirm-submit"]
        if "--browser-mode" in Path(result["submitter"]).read_text(encoding="utf-8"):
            command += ["--browser-mode", "local-cdp"]
        raise SystemExit(subprocess.call(command))
    except (ValueError, OSError, ImportError, subprocess.CalledProcessError, EOFError) as exc:
        print("未启动提交：" + str(exc), file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
