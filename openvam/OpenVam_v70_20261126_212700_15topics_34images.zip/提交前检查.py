#!/usr/bin/env python3
"""Portable offline delivery validation. No generation rules or cloud access."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tempfile
from PIL import Image


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def safe(root, name):
    require(isinstance(name, str) and name, 'Missing relative path')
    p = PurePosixPath(name)
    require(p.parts and p.as_posix() == name and not p.is_absolute()
            and '..' not in p.parts and '\\' not in name and ':' not in name, 'Unsafe path: ' + name)
    target = Path(root).joinpath(*p.parts)
    require(not any(p.is_symlink() for p in [target, *target.parents]), 'Symlink rejected')
    return target


def stage_hash(path):
    """Authenticate every field except the intentionally relocatable folder value."""
    data = read(path)
    for item in data['topics']:
        item.pop('folder', None)
    return hashlib.sha256(json.dumps(data, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def file_hash(root, name):
    path = safe(root, name)
    return stage_hash(path) if name == '.workflow/final_stage.json' else digest(path)


def validate_final(root, relocate=False):
    root = Path(root).resolve()
    sums = read(root / 'SHA256.json')
    require(isinstance(sums, dict) and sums, 'Missing package checksums')
    actual_files = set()
    for p in root.rglob('*'):
        require(not p.is_symlink(), 'Symlink rejected')
        if p.is_file() and p.name != 'SHA256.json' and '__pycache__' not in p.parts and p.suffix != '.pyc':
            actual_files.add(p.relative_to(root).as_posix())
    require(actual_files == set(sums), 'Unexpected or missing package files')
    for name, expected in sums.items():
        require(file_hash(root, name) == expected, 'Final package hash mismatch: ' + name)
    manifest = read(root / '.workflow/run_manifest.json')
    require(manifest.get('workflow') == 'openvam-pair-v1', 'Unsupported workflow')
    run = manifest['run_id']
    require(isinstance(run, str) and run, 'Missing run identity')
    topics = manifest['topics']
    require(isinstance(topics, list) and topics, 'Empty batch')
    stage = read(root / '.workflow/final_stage.json')
    require(stage['run_id'] == run and len(stage['topics']) == len(topics), 'Final batch identity mismatch')
    ids, folders, states = set(), set(), []
    for item, record in zip(topics, stage['topics']):
        name = item['folder_name']
        folder = safe(root, name)
        require(len(PurePosixPath(name).parts) == 1 and name not in folders, 'Invalid topic folder')
        require(item['topic_id'] not in ids and item.get('relative_dir', name) == name, 'Invalid topic identity')
        ids.add(item['topic_id']); folders.add(name)
        expected_identity = dict(run_id=run, topic_id=item['topic_id'], topic=item['topic'])
        def identity(data):
            require(all(data.get(k) == v for k, v in expected_identity.items()), 'Topic identity mismatch')
        identity(read(folder / '.workflow/task.json'))
        require((folder / '.workflow/run_id.txt').read_text().strip() == run, 'Run marker mismatch')
        cp = folder / '.workflow/copy_result.json'
        copy = read(cp)
        identity(copy)
        require(copy.get('status') in ('completed', 'failed'), 'Incomplete copy')
        state = 'failed'
        reason = copy.get('error_code')
        saved_pages = []
        if copy['status'] == 'completed':
            pages = copy['pages']
            require(2 <= len(pages) <= 18 and [p['page'] for p in pages] == list(range(1, len(pages)+1)), 'Invalid planned pages')
            refs = {}
            for ref in copy['reference_images']:
                require(ref['id'] not in refs, 'Duplicate reference')
                refs[ref['id']] = ref
                require(digest(safe(folder, ref['local_path'])) == ref['sha256'], 'Reference hash mismatch')
            for page in pages:
                require(all(i in refs for i in page['image_ids']), 'Missing reference mapping')
                if 'template_path' in page:
                    require(digest(safe(folder, page['template_path'])) == page['template_sha256'], 'Template hash mismatch')
                elif copy.get('task_type') == 'steps':
                    raise ValueError('Missing steps template')
            poster = read(folder / '.workflow/poster_result.json')
            identity(poster)
            require(poster.get('copy_sha256') == digest(cp), 'Poster copy revision mismatch')
            require(poster['status'] in ('completed', 'failed'), 'Incomplete posters')
            reason = poster.get('error_code')
            if poster['status'] == 'completed':
                state = 'poster_ready'
                numbers = [p['page'] for p in poster['pages']]
                require(all(type(n) is int for n in numbers) and sorted(numbers) == list(range(1, len(pages)+1)), 'Invalid saved pages')
                for page in poster['pages']:
                    filename = f"海报_{page['page']:02d}.png"
                    require(page['filename'] == filename, 'Invalid poster filename')
                    path = folder / filename
                    require(digest(path) == page['sha256'], 'Poster hash mismatch')
                    with Image.open(path) as im:
                        require(im.format == 'PNG', 'Poster must be PNG')
                        im.verify()
                    with Image.open(path) as im:
                        im.load()
                        w, h = im.size
                        require(w * 4 == h * 3 and w > 0, 'Poster must be strict 3:4')
                        require(getattr(im, 'n_frames', 1) == 1, 'Animated PNG rejected')
                        require(im.convert('RGBA').getchannel('A').getextrema() == (255, 255), 'Poster must be opaque')
                        require(page['width'] == w and page['height'] == h, 'Poster dimension mismatch')
                require({p.name for p in folder.glob('海报_*.png')} == {p['filename'] for p in poster['pages']}, 'Unexpected posters')
                saved_pages = sorted(numbers)
        if state == 'failed':
            require(isinstance(reason, str) and reason, 'Missing failure reason')
            require(record.get('reason') == reason, 'Failure reason mismatch')
        for key in ('topic_id', 'topic', 'folder_name'):
            require(record.get(key) == item[key], 'Final topic order or identity mismatch')
        require(record['state'] == state, 'Final topic state mismatch')
        states.append(dict(item, state=state, saved_pages=saved_pages, **({'reason': reason} if state == 'failed' else {})))
        if relocate:
            record['folder'] = str(folder)
    success = sum(t['state'] == 'poster_ready' for t in states)
    require(stage['success'] == success and stage['failed'] == len(states)-success, 'Final counts mismatch')
    if relocate:
        target = root / '.workflow/final_stage.json'
        content = json.dumps(stage, ensure_ascii=False, indent=2) + '\n'
        if target.read_text(encoding='utf-8') != content:
            with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=target.parent, delete=False) as f:
                f.write(content)
            os.replace(f.name, target)
    return dict(run_id=run, success=success, failed=len(states)-success, topics=states,
                offline_integrity='passed', live_submission='not_tested')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['preflight'])
    parser.add_argument('--root', required=True)
    parser.add_argument('--relocate', action='store_true')
    args = parser.parse_args()
    try:
        print(json.dumps(validate_final(args.root, args.relocate), ensure_ascii=False, indent=2))
    except (ValueError, OSError, KeyError, TypeError, SyntaxError) as exc:
        parser.exit(1, json.dumps({'error': str(exc)}, ensure_ascii=False) + '\n')


if __name__ == '__main__':
    main()
